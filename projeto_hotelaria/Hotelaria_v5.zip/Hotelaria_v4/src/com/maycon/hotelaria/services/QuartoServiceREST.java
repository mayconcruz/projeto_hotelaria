/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maycon.hotelaria.services;

import com.maycon.hotelaria.estruturas.Quarto;
import java.util.List;

/**
 *
 * @author kennedyoliveira
 */
public class QuartoServiceREST implements QuartoService {

    @Override
    public boolean cadastraQuarto(Quarto quarto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Quarto> consultaTodosQuartos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Quarto> consultaQuartosDisponiveis(String tipo, String dataInicio, String dataFinal) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}

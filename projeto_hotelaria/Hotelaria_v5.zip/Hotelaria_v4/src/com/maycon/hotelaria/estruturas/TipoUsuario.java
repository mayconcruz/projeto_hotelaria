package com.maycon.hotelaria.estruturas;

/**
 * A classe do tipo ENUM representa os possíveis níveis de usuário para acesso ao sistema
 */
public enum TipoUsuario {
    ADMINISTRADOR, COMUM

}
